import React, { useState } from 'react';
import Heading from './Components/Heading'
import StudentList from './Components/StudenList'
import StudentListForm from './Components/StudentListForm'
import './App.css';

function App () {
    const [students, setStudents] = useState([
      {
        id: 1,
        name: 'John Doe',
        year: 1,
        active: true
      },
      {
        id: 2,
        name: 'Dani Filth',
        year: 2,
        active: false
      },
      {
        id: 3,
        name: 'Dante Gulapa',
        year: 3,
        active: true
      },

    ]);

    const addStudent = (student) => {
      setStudents([...students, student])
    }

    const newStudent = {
      id: 5,
      name: 'Taning',
      year: 3,
      active: true
    }

    return (
      <div className="App">
        <Heading/>
        <StudentListForm addStudent = { addStudent }/>
        <StudentList students = { students } />
      </div>
    );
  }


export default App;
