import React from 'react';
import StudentListItem from './StudentListItem'
import '../styles/StudentList.css';

function StudentList({ students }){
  return(
    <ul className = "students-list">
    {
      students.map(student => <StudentListItem student = { student }/> )
    }
    </ul>
  )
}

export default StudentList