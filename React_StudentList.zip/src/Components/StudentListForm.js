import React, {useState} from 'react';

function StudentListForm( { addStudent }) {
  const [student, setStudent] = useState('');
  const [active, setActive] = useState(false);

  const handleChange = (e) => {
    setStudent(e.target.value)
  }

  const handleActive = (e) => {
    setActive(e.target.value);
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    addStudent({
      id: 5,
      name: student,
      year: 3,
      active: active
    });
    setStudent('')
  }

  return(
    <form onSubmit = {handleSubmit}>
      <label>Student Name</label>
      <input 
        onChange = { handleChange } 
        value = { student }
        type = "text" />
      <select onChange = { handleActive} value = { active }>
      <option value = {true}>Active</option>
      <option value = {false}>Inactive</option>
      </select>
    </form>
  )
}

export default StudentListForm