import React from 'react';

function StudentListItem({ student: { id, name, year, active } }) {
  return(
    <li className = { active ? 'active' : 'inactive' } >{ id + ' ' + name + ' ' + year }</li>
    //<li>{ id } { name } </li>
  )
}

export default StudentListItem