import React from 'react';

function Heading (){
  return(
    <header>
    <h1>Students Lists</h1>
    </header>
  )
}

export default Heading